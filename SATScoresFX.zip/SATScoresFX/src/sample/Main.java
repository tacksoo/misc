package sample;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception{
       String xmlData = downloadData("https://data.ct.gov/api/views/kbxi-4ia7/rows.xml?accessType=DOWNLOAD");
       ArrayList<String> highSchoolNames = getHighSchoolNames(xmlData);
       highSchoolNames.add("GGC");
        System.out.println(highSchoolNames);
       ArrayList<String> participationRate = getParticipationRate(xmlData);
       ArrayList<HighSchool> hs = new ArrayList<HighSchool>();
        for (int i = 0; i < highSchoolNames.size(); i++) {
            HighSchool h = new HighSchool(highSchoolNames.get(i),
                    Integer.parseInt(participationRate.get(i)));
            hs.add(h);
        }
        Collections.sort(hs);
        System.out.println(hs);
    }

    private ArrayList<String> getParticipationRate(String xmlData) {
        ArrayList<String> rates = new ArrayList<String>();
        Pattern p = Pattern.compile("<participation_rate_estimate_2013>([0-9]+)</participation_rate_estimate_2013>");
        Matcher m = p.matcher(xmlData);
        while(m.find()) {
            rates.add(m.group(1));
        }
        return rates;
    }

    private ArrayList<String> getHighSchoolNames(String xmlData) {
        ArrayList<String> names = new ArrayList<String>();
        Pattern p = Pattern.compile("<school>([a-zA-Z .]+)</school>");
        Matcher m = p.matcher(xmlData);
        while(m.find()) {
            names.add(m.group(1));
        }
        return names;
    }


    private String downloadData(String str) {
        String data = "";
        try {
            URL url = new URL(str);
            InputStream in = url.openStream();
            InputStreamReader isr = new InputStreamReader(in);
            BufferedReader br = new BufferedReader(isr);
            String line = br.readLine();
            while(line != null) {
                data += line;
                line = br.readLine();
            }
        } catch(IOException e) {
            e.printStackTrace();
        }
        return data;
    }


    public static void main(String[] args) {
        launch(args);
    }
}
