public interface Moveable {

    public void tick();

}
