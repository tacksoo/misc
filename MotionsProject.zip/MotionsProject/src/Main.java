import java.awt.*;
import java.util.Random;

public class Main {

    public static void main(String[] args) {
        DrawingPanel panel = new DrawingPanel(500,500);
        Random r = new Random();
        Graphics g = panel.getGraphics();
        Color c = new Color(r.nextInt(256), r.nextInt(256), r.nextInt(256));
        Color c2 = new Color(r.nextInt(256), r.nextInt(256), r.nextInt(256));
        Color c3 = new Color(r.nextInt(256), r.nextInt(256), r.nextInt(256));
        int x = r.nextInt(501);
        int y = r.nextInt(501);
        Triangle t = new Triangle(0,155, c, 30, 40, 50);
        while(true) {
            t.draw(g);
            t.tick();
            try {
                Thread.sleep(50);
            } catch(Exception e) {

            }
            g.setColor(new Color(255,255,255));
            g.fillRect(0,0,500,500);
        }
    }
}