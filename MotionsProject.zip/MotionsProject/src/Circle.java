import java.awt.*;

public class Circle extends Shape implements Moveable {
    private int radius;

    public Circle(int x, int y, Color c,int radius) {
        super(x, y, c);
        this.radius = radius;
    }


    @Override
    public double area() {
        return Math.PI * radius * radius;
    }

    @Override
    public double perimeter() {
        return 2* Math.PI * radius;
    }

    @Override
    public void draw(Graphics g) {
        g.setColor(getColor());
        g.fillOval(getX(),getY(),radius,radius);
    }

    @Override
    public void tick() {

    }
}
