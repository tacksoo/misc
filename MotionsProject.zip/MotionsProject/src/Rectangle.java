import java.awt.*;

public class Rectangle extends Shape implements Moveable {

    private int width;
    private int height;

    public Rectangle(int x, int y, Color c, int width, int height) {
        super(x, y, c);
        this.width = width;
        this.height = height;
    }

    @Override
    public double area() {
        return width*height;
    }

    @Override
    public double perimeter() {
        return 2*width + 2*height;
    }

    @Override
    public void draw(Graphics g) {
        g.setColor(getColor());
        g.fillRect(getX(),getY(),width,height);
    }

    @Override
    public void tick() {

    }
}
