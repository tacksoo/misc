import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import java.util.List;


public class BannerTest {

    private static WebDriver driver;

    @BeforeClass
    public static void setUpSelenium() {
        System.setProperty("webdriver.chrome.driver",
                "C:\\Users\\tim\\Desktop\\chromedriver.exe");
        driver = new ChromeDriver();
    }

    @Test
    public void downloadCourses() {
        driver.get("https://ggc.gabest.usg.edu/pls/B400/bwckschd.p_disp_dyn_sched");
        //link.click();
        Select semester = new Select(driver.findElement(By.name("p_term")));
        semester.selectByVisibleText("Fall 2019");
        WebElement submit = driver.findElement(By.xpath("/html/body/div[3]/form/input[2]"));
        submit.click();
        //Select subject = new Select(driver.findElement(By.name("sel_subj")));
        //subject.selectByVisibleText("Information Technology");
        WebElement itec = driver.findElement(By.xpath("//*[@id=\"subj_id\"]/option[26]"));
        itec.click();
        WebElement submit2 = driver.findElement(By.xpath("/html/body/div[3]/form/input[12]"));
        submit2.click();
        List<WebElement> links = driver.findElements(By.tagName("a"));
        for (WebElement e: links ) {
            System.out.println(e.getAttribute("href"));
            // regular expressions
        }
    }

    @Test
    public void regexTest() {
       String str = "itec 4260";
       boolean b = str.matches("[0]$");
       System.out.println(b);
    }

}
