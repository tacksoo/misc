package com.example;

public class Course {
    private String name;
    private String number;
    private int numStudents;
    private String semester;
    private int creditHours;
    private String subject;

    public Course(String name, String number, int numStudents, String semester, int creditHours, String subject) {
        this.name = name;
        this.number = number;
        this.numStudents = numStudents;
        this.semester = semester;
        this.creditHours = creditHours;
        this.subject = subject;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public int getNumStudents() {
        return numStudents;
    }

    public void setNumStudents(int numStudents) {
        this.numStudents = numStudents;
    }

    public String getSemester() {
        return semester;
    }

    public void setSemester(String semester) {
        this.semester = semester;
    }

    public int getCreditHours() {
        return creditHours;
    }

    public void setCreditHours(int creditHours) {
        this.creditHours = creditHours;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }
}
