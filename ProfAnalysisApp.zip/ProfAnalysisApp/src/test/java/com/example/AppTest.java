package com.example;

import static org.junit.Assert.assertTrue;

import org.junit.Assert;
import org.junit.Test;

import java.util.List;

/**
 * Unit test for simple App.
 */
public class AppTest 
{
    /**
     * Rigorous Test :-)
     */
    @Test
    public void testGetProfCourses(){
        //List<Course> courses = BannerUtility.getProfCourses("Tacksoo Im","Spring 2021");
        //Assert.assertTrue(courses.size() > 0);
        List<Course> fallCourses = BannerUtility.getProfCourses("Tacksoo Im", "Fall 2020");
        Assert.assertEquals(4, fallCourses.size());
    }

}


