import java.awt.*;

public class Circle extends Shape implements Moveable {

    private int radius;
    private double angle = 0;

    public Circle(int x, int y, Color c, int radius) {
        super(x, y, c);
        this.radius = radius;
    }

    @Override
    public void tick() {
        this.setX( this.getX() + 1 );
        this.setY( (int) (100 * Math.sin(this.angle)) + 200);
        angle = angle + 0.1;
    }

    @Override
    public double area() {
        return Math.PI * radius * radius;
    }

    @Override
    public double perimeter() {
        return 2 * Math.PI * radius;
    }

    @Override
    public void draw(Graphics g) {
        g.setColor(this.getColor());
        g.fillOval(this.getX(), this.getY(), radius, radius);
    }
}
