import java.awt.*;
import java.util.Random;

public class Whacky extends Shape{

    @Override
    public double area() {
        return 0;
    }

    @Override
    public double perimeter() {
        return 0;
    }

    public Whacky(int x, int y, Color c) {
        super(x, y, c);
    }

    @Override
    public void draw(Graphics g) {
        Random r = new Random();
        Color c = new Color(r.nextInt(256),r.nextInt(256),r.nextInt(256));
        g.setColor(c);
        Polygon p = new Polygon();
        p.addPoint(getX()-10, getY()+10);
        p.addPoint(getX()+10, getY()+10);
        p.addPoint(getX()+20,getY() +20);
        g.drawPolygon(p);
    }
}
