import java.awt.*;
import java.util.Random;

public class RecursionDrawing {

    public static void main(String[] args) {
        DrawingPanel panel = new DrawingPanel(500,500);
        Graphics g = panel.getGraphics();
        //drawMyRect(g, 500,500);
        drawMyCircle(g, 250);
    }

    public static void drawMyRect(Graphics g,int width, int height) {
        if(width == 0 && height == 0)
           return;
        else {
            Random r = new Random();
           Color color = new Color(r.nextInt(256),r.nextInt(256),r.nextInt(256));
           g.setColor(color);
           g.fillRect(0,0,width, height);
           drawMyRect(g, (int)(width*0.9), (int) (height*0.9));
        }
    }

    public static void drawMyCircle(Graphics g, int radius) {
        if( radius == 1) {
            return;
        } else {
            g.drawOval(250-radius/2,250-radius/2, radius, radius);
            drawMyCircle(g, (int) (radius * 1.1) );
        }
    }
}
