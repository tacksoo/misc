import java.awt.*;
import java.util.Random;

public class Main {

    public static void main(String[] args) {
        DrawingPanel panel = new DrawingPanel(500,500);
        Random r = new Random();
        Graphics g = panel.getGraphics();
        while(true) {
            int x = r.nextInt(501);
            int y = r.nextInt(501);
            Color c = new Color(r.nextInt(256), r.nextInt(256), r.nextInt(256));
            Triangle t = new Triangle(x,y,c,30,40,50);
            t.draw(g);
            try {
                Thread.sleep(50);
            } catch(Exception e) {

            }
        }
    }
}
