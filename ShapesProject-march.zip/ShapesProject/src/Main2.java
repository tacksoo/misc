import java.awt.*;
import java.util.Random;

public class Main2 {

    public static void main(String[] args) {
        DrawingPanel panel = new DrawingPanel(500,500);
        Graphics g = panel.getGraphics();
        Random r = new Random();
        Color color = new Color(r.nextInt(256),r.nextInt(256), r.nextInt(256));
        Circle myCircle = new Circle(0,300, color, 30);
        CheckerBoard cb = new CheckerBoard(0,0,color);
        while(true) {
           // myCircle.draw(g);
           // myCircle.tick();
            cb.draw(g);

            try {
                Thread.sleep(10);
            } catch(Exception e) {

            }
            //g.setColor(Color.WHITE);
           // g.fillRect(0,0,500,500);
        }
    }
}
