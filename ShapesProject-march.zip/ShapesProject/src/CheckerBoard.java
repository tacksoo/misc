import java.awt.*;

public class CheckerBoard extends Shape {

    public CheckerBoard(int x, int y, Color c) {
        super(x, y, c);
    }

    @Override
    public double area() {
        return 0;
    }

    @Override
    public double perimeter() {
        return 0;
    }

    @Override
    public void draw(Graphics g) {
        int current_x = 0;
        int current_y = 0;
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                g.fillRect(current_x, current_y, 50, 50);
                current_x = current_x + 50;
                if(g.getColor() == Color.BLACK)
                    g.setColor(Color.RED);
                else
                    g.setColor(Color.BLACK);
            }
            if( i%2 == 0)
                g.setColor(Color.BLACK);
            else
                g.setColor(Color.RED);
            current_y = current_y + 50;
            current_x = 0;
        }

    }
}
