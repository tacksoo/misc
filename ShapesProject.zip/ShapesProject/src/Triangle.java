import java.awt.*;

public class Triangle extends Shape {

    private double sideA;
    private double sideB;
    private double sideC;

    public Triangle(int x, int y, Color c,double sideA, double sideB, double sideC) {
        super(x, y, c);
        this.sideA = sideA;
        this.sideB = sideB;
        this.sideC = sideC;
    }

    @Override
    public double area() {
        double s = (sideA + sideB + sideC)/3;
        return Math.sqrt(s * (s - sideA) * (s - sideB) * (s - sideC));
    }

    @Override
    public double perimeter() {
        return sideA + sideB + sideC;
    }

    @Override
    public void draw(Graphics g) {
        g.setColor(getColor());
        Polygon p = new Polygon();
        double max = Math.max(Math.max(sideA,sideB),sideC);
        double min = Math.min(Math.min(sideA,sideB),sideC);
        double middle = sideA + sideB + sideC - max - min;
        p.addPoint(getX(),getY());
        p.addPoint(getX(),(int) (getY()+min));
        p.addPoint((int) (getX() + middle),(int) (getY()+min));
        g.fillPolygon(p);
    }
}
