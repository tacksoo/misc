package sample;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DeserializeExample {

    public static void main(String[] args) {
        DeserializeExample d = new DeserializeExample();
        ArrayList<String> names = d.getNames();
        ArrayList<String> ages = d.getAges();
        ArrayList<String> filenames = d.getFileNames();
        ArrayList<Person> persons = new ArrayList<Person>();
        for (int i = 0; i < names.size(); i++) {
            int age = Integer.parseInt(ages.get(i));
            Person p = new Person(names.get(i),age,filenames.get(i));
            persons.add(p);
        }
        Collections.sort(persons);
        System.out.println(persons);
    }

    public String getFileContent() {
        String str = "";
        try {
            Scanner scanner = new Scanner(new File("src/names.xml"));
            while(scanner.hasNextLine()) {
                str = str + scanner.nextLine();
            }
            scanner.close();
        } catch(Exception e) {
            e.printStackTrace();
        }

        return str;
    }

    public ArrayList<String> getNames() {
        Pattern p = Pattern.compile("<name>([a-zA-Z]+)</name>");
        Matcher m = p.matcher(getFileContent());
        ArrayList<String> names = new ArrayList<String>();
        while( m.find() ) {
            names.add(m.group(1));
        }
        return names;
    }

    public ArrayList<String> getAges() {
        Pattern p = Pattern.compile("<age>([0-9]+)</age>");
        Matcher m = p.matcher(getFileContent());
        ArrayList<String> ages = new ArrayList<String>();
        while( m.find() ) {
            ages.add(m.group(1));
        }
        return ages;
    }

    public ArrayList<String> getFileNames() {
        Pattern p = Pattern.compile("<filename>([a-zA-Z.]+)</filename>");
        Matcher m = p.matcher(getFileContent());
        ArrayList<String> filenames = new ArrayList<String>();
        while( m.find() ) {
            filenames.add(m.group(1));
        }
        return filenames;
    }
}
