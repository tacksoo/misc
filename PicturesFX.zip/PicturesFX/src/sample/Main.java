package sample;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Main extends Application {

    private Button previous;
    private Button next;
    private ArrayList<Person> names;
    private Label nameDataLabel;
    private Label ageDataLabel;
    private ImageView imageView;
    private int index = 0;

    @Override
    public void start(Stage primaryStage) throws Exception{
        setUpNames();
        setUI(primaryStage);
        setUpHandlers();
        printFile();
    }

    private void printFile() throws Exception {
        Scanner scanner = new Scanner(new File("res/people.txt"));
        while(scanner.hasNextLine()) {
            System.out.println(scanner.nextLine());
        }
    }

    private void setUpHandlers() {
        previous.setOnAction( e -> {
            if( index < 0) {
                index = names.size() - 1;
            }
            nameDataLabel.setText(names.get(index).getName());
            ageDataLabel.setText(names.get(index).getAge() + "");
            index -= 1;
        });

        next.setOnAction( e -> {
            if( index > names.size() - 1 || index == -1) {
                index = 0;
            }
            nameDataLabel.setText(names.get(index).getName());
            ageDataLabel.setText(names.get(index).getAge() + "");
            index += 1;
        });
    }

    private void setUpNames() {
        names = new ArrayList<Person>();
        names.add(new Person("kim",30,"src/kim.jpg"));
        names.add(new Person("khloe",27, "src/khloe.jpg"));
        names.add(new Person("kourtney",25, "src/koutney.jpg"));
        Collections.sort(names);
        System.out.println(names);
    }

    private void setUI(Stage primaryStage) {
        VBox vbox = new VBox();
        vbox.setSpacing(15);
        GridPane grid = new GridPane();
        BorderPane pane = new BorderPane();
        pane.setPadding(new Insets(15,15,15,15));
        Label nameLabel = new Label("Name");
        Label ageLabel = new Label("Age");
        grid.add(nameLabel,0,0);
        grid.add(ageLabel,0,1);
        nameDataLabel = new Label("--------");
        ageDataLabel = new Label("--------");
        grid.add(nameDataLabel,1,0);
        grid.add(ageDataLabel,1,1);
        previous = new Button("Previous");
        next = new Button("Next");
        grid.add(previous, 0,2);
        grid.add(next, 1,2);
        vbox.getChildren().add(grid);
        vbox.setAlignment(Pos.CENTER);
        pane.setCenter(vbox);
        primaryStage.setScene(new Scene(pane,500,500));
        primaryStage.show();
    }


    public static void main(String[] args) {
        launch(args);
    }
}
