package sample;

import java.util.HashMap;

public class HashMapExample {

    public static void main(String[] args) {
        HashMap<String,String> states = new HashMap<String,String>();
        states.put("GA","Georgia");
        states.put("NY","New York");
        states.put("AL","Alabama");
        states.put("CO","Colorado");
        states.put("WA","Washington");
        states.put("FL","Florida");
        states.put("CA","California");
        states.put("KY","Kentucky");
        for(String key: states.keySet()) {
            System.out.println(key + " : " + states.get(key) );
        }
        //states.put("GA","The great state of Georgia");

        System.out.println(states.get("OR"));

        HashMap<String,Double> prices = new HashMap<String,Double>();
        prices.put("regular",6.99);
        prices.put("decaf",6.98);
        prices.put("sugar",4.99);
        prices.put("caramel",5.99);

        System.out.println(prices.get("decaf"));

    }
}
