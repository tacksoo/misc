package sample;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexExample {

    public static void main(String[] args) {
//        String zipCode = "30043";
//        boolean test = zipCode.matches("\\d{5}");
//        System.out.println(test);
        String str = "I live in 30043 but I used to live in 30302";
        Pattern pattern = Pattern.compile("\\d{5}");
        Matcher matcher = pattern.matcher(str);
        while( matcher.find() ) {
            System.out.println( str.substring(matcher.start(), matcher.end()) );
        }
    }
}
