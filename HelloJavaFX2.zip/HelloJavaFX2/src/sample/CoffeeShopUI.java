package sample;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.io.FileInputStream;
import java.util.HashMap;
import java.util.Map;

public class CoffeeShopUI extends Application {

    private Scene scene;
    private HashMap<String,Double> prices;
    private Button regular;
    private Button decaf;
    private Button latte;
    private Button mocha;
    private CheckBox sugar;
    private CheckBox caramel;
    private HashMap<String,Integer> order;

    public void calculateTotal() {
        double total = 0;
        if (sugar.isSelected()) {
            total += (double) prices.get("sugar");
        }
        if (caramel.isSelected()) {
            total += (double) prices.get("caramel");
        }
        for(String product: order.keySet()) {
           double price = prices.get(product);
           int num = order.get(product);
           total = total + (price * num);
        }
        System.out.println("Total price is: " + total);
        double withTax = total + (total*0.06);
        System.out.println("Total price with Tax: " + withTax);
    }

    public void productSelected(String product) {
        if(order.containsKey(product)) {
            int num = (int) order.get(product);
            num += 1;
            order.put(product,num);
        } else {
            order.put(product,1);
        }
        printOrder();
    }

    public void printOrder() {
        System.out.println("------------------ Current Order -------------------");
        for(String product: order.keySet()) {
            System.out.println(product + " x " + order.get(product) );
        }
        System.out.println("----------------------------------------------------");
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        prices = new HashMap<String,Double>();
        order = new HashMap<String,Integer>();
        prices.put("regular",6.99);
        prices.put("decaf",6.98);
        prices.put("sugar",4.99);
        prices.put("caramel",5.99);
        prices.put("latte",11.99);
        prices.put("mocha",13.99);
        GridPane layout = new GridPane();
        layout.setPadding(new Insets(10,10,10,10));
        layout.setVgap(10);
        layout.setHgap(10);
        FileInputStream fis = new FileInputStream("res/logo.PNG");
        Image image = new Image(fis);
        ImageView im = new ImageView(image);
        //layout.add(im,0,0);
        regular = new Button("Regular");
        regular.setOnAction( e -> productSelected("regular"));
        regular.setMinSize(100,100);
        decaf = new Button("Decaf");
        decaf.setOnAction( e -> productSelected("decaf"));
        decaf.setMinSize(100,100);
        latte = new Button("Latte");
        latte.setOnAction( e -> productSelected("latte"));
        latte.setMinSize(100,100);
        mocha = new Button("Mocha");
        mocha.setOnAction( e -> productSelected("mocha"));
        mocha.setMinSize(100,100);
        layout.add(regular,0,0);
        layout.add(decaf, 1,0);
        layout.add(latte, 2, 0);
        layout.add(mocha, 3,0);
        sugar = new CheckBox("Sugar");
        caramel = new CheckBox("Caramel");
        layout.add(sugar,1,1);
        layout.add(caramel,2,1);
        Button calculate = new Button("Total");
        calculate.setOnAction( e -> calculateTotal() );
        layout.add(calculate,0,2);
        //layout.add(new Label("Dr. Im's Coffee Shop"),2,1,2,2);
        scene = new Scene(layout,600,500);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Dr. Im's Coffee Shop");
        primaryStage.show();
    }
}
