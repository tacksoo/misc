package sample;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.Buffer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DownloadWeather {

    public static void main(String[] args) {
        try {
            URL url = new URL("https://api.darksky.net/forecast/3c5084c558861c1610447b49a45f4eb4/40.8091382,-96.8088597");
            InputStream in = url.openStream();
            InputStreamReader isr = new InputStreamReader(in);
            BufferedReader br = new BufferedReader(isr);
            String line = br.readLine();
            String str = "";
            while(line != null) {
                str = str + line;
                line = br.readLine();
            }
            Pattern pattern = Pattern.compile("\"temperature\":(\\d+.\\d+),");
            Matcher matcher = pattern.matcher(str);
            System.out.println(matcher.find());
            System.out.println(str.substring(matcher.start(),matcher.end()));
            System.out.println(matcher.group(1));
        } catch(IOException e) {
            e.printStackTrace();
        }
    }
}
