package sample;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Main extends Application {

    private Button button1;
    private Button button2;
    private Scene scene1;
    private Scene scene2;
    private Stage primaryStage;

    public void setUpScene1() {
        Insets insets = new Insets(50,50,50,50);
        VBox layout = new VBox();
        layout.setPadding(insets);
        button1 = new Button("Go to scene 2");
        button1.setOnAction( e -> primaryStage.setScene(scene2));
        layout.getChildren().add(button1);
        scene1 = new Scene(layout,500,500);
    }

    public void setUpScene2() {
        Insets insets = new Insets(50,50,50,50);
        HBox layout = new HBox();
        layout.setPadding(insets);
        button2 = new Button("Go back to scene 1");
        button2.setOnAction( e -> primaryStage.setScene(scene1) );
        layout.getChildren().add(button2);
        scene2 = new Scene(layout, 1000,500);
    }
    @Override
    public void start(Stage primaryStage) throws Exception{
        this.primaryStage = primaryStage;
        setUpScene1();
        setUpScene2();
        primaryStage.setTitle("Hello World");
        primaryStage.setScene(scene1);
        primaryStage.show();

    }


    public static void main(String[] args) {
        launch(args);
    }
}
